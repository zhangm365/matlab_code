clear all;
format long;
addpath('functions');
load data\circleTrackingData.mat;
load data\circleParameter.mat
global d;
d = 0.05;

number = Td/step+1;
actualPosition = zeros(number,3);
Error = zeros(number,3);

% step = 0.01;

%Ŀ��켣
T = 0:step:20;
% % %circle
rdx = iota*cos(2*pi*sin(0.5*pi*T/Td).^2)-iota+0.0907;
rdy = iota*cos(pi/6)*sin(2*pi*sin(0.5*pi*T/Td).^2);
rdz = iota*sin(pi/6)*sin(2*pi*sin(0.5*pi*T/Td).^2)+0.3859;
% % quadrangle
% T = 0:step:4.99;
% xdx1 = -0.03*4*T/Td+0.0907;
% xdy1 = 0.06*4*T/Td+0.00001;
% xdz1 = 0.01*4*T/Td+0.3859;
% T = 5:step:9.99;
% xdx2 = -0.03*4*(T-Td/4)/Td+0.0607;
% xdy2 = -0.06001*4*(T-Td/4)/Td+0.06001;
% xdz2 = -0.01*4*(T-Td/4)/Td+0.3959;
% T = 10:step:14.99;
% xdx3 = 0.03*4*(T-2*Td/4)/Td+0.0307;
% xdy3 = -0.06*4*(T-2*Td/4)/Td;
% xdz3 = 0.01*4*(T-2*Td/4)/Td+0.3859;     
% T = 15:step:20;
% xdx4 = 0.03*4*(T-3*Td/4)/Td+0.0607;
% xdy4 = 0.06001*4*(T-3*Td/4)/Td-0.06;
% xdz4 = -0.01*4*(T-3*Td/4)/Td+0.3959;
% rdx = [xdx1, xdx2, xdx3, xdx4];
% rdy = [xdy1, xdy2, xdy3, xdy4];
% rdz = [xdz1, xdz2, xdz3, xdz4];

%ʵ�ʹ켣
for i = 1:number
    q = U(i,1:6)';
    [px, py, pz] = position(q);
    %ĩ��
    actualPosition(i, 1:3) = [px, py, pz];
    %���
    Error(i,:) = [px-rdx(i), py-rdy(i), pz-rdz(i)];
end
% figure;
% plot3(actualPosition(1:number,1)', actualPosition(1:number,2)', actualPosition(1:number,3)','r:*');grid on;
% hold on;
% plot3(rdx, rdy, rdz,'b'); 
% legend('Actual trajactory','Desired path','Location','best');
% hold off;
% xlabel('X (m)');
% ylabel('Y (m)');
% zlabel('Z (m)');
% savefig('results\Circle.fig');

%������
figure;
Te = 0:step:20;
plot(Te,Error(:,1)*1000','-', 'linewidth', 2);
hold on;
plot(Te,Error(:,2)'*1000,'--', 'linewidth', 2);%grid on;
plot(Te,Error(:,3)'*1000,':', 'linewidth', 2);
RMSE = round(sqrt(sum(Error(:,1).^2 + Error(:,2).^2 + Error(:,3).^2)/number)*1000, 4);
annotation = strcat('RMSE=',mat2str(RMSE),'mm');
text(6, -2, annotation, 'fontsize', 14, 'FontName', 'times new Roman');
legend('Ex','Ey','Ez','Location','best', 'FontName', 'times new Roman');
hold off;
xlabel('Time (s)', 'FontName', 'times new Roman');
ylabel('Error (mm)', 'FontName', 'times new Roman');
savefig('results\circleErrorKalman.fig');

% bellows
q1 = U(:, 1)'; q2 = U(:, 2)'; q3 = U(:, 3)'; q4 = U(:, 4)'; q5 = U(:, 5)'; q6 = U(:, 6)';
t = 0:step:Td;
figure;
plot(t, q1*1000, 'r-', 'linewidth', 2);grid on;
hold on;
plot(t, q2*1000, 'b--', 'linewidth', 2);
plot(t, q3*1000, 'g:', 'linewidth', 2);
plot(t, q4*1000, 'c-', 'linewidth', 2);
plot(t, q5*1000, 'm--', 'linewidth', 2);
plot(t, q6*1000, 'y:', 'linewidth', 2);
hold off;
xlabel('Time (s)', 'FontName', 'times new Roman');
ylabel('Bellow length (mm)', 'FontName', 'times new Roman');
legend('u21', 'u22', 'u23','u11', 'u12', 'u13', 'FontName', 'times new Roman');
savefig('results\circleBellowsKalman.fig');

