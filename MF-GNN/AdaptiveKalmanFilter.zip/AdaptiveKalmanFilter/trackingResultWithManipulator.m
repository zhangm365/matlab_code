clear;
addpath('functions');
addpath('drawManipulator');
load data\circleTrackingData.mat;
load data\circleParameter.mat

global d;
d = 0.05;

inteval = 5;
number = fix((Td/step+1)/inteval);
pos = zeros(number,3);
Error = zeros(number,3);
index = 0;

%Ŀ��켣
T = 0:step:20;
% %circle
rdx = iota*cos(2*pi*sin(0.5*pi*T/Td).^2)-iota+0.0907;
rdy = iota*cos(pi/6)*sin(2*pi*sin(0.5*pi*T/Td).^2);
rdz = iota*sin(pi/6)*sin(2*pi*sin(0.5*pi*T/Td).^2)+0.3859;
% rectangle
% T = 0:step:5-step;
% xdx1 = -0.03*4*T/Td+0.0907;
% xdy1 = 0.06*4*T/Td+0.00001;
% xdz1 = 0.01*4*T/Td+0.3859;
% T = 5:step:10-step;
% xdx2 = -0.03*4*(T-Td/4)/Td+0.0607;
% xdy2 = -0.06001*4*(T-Td/4)/Td+0.06001;
% xdz2 = -0.01*4*(T-Td/4)/Td+0.3959;
% T = 10:step:15-step;
% xdx3 = 0.03*4*(T-2*Td/4)/Td+0.0307;
% xdy3 = -0.06*4*(T-2*Td/4)/Td;
% xdz3 = 0.01*4*(T-2*Td/4)/Td+0.3859;     
% T = 15:step:20;
% xdx4 = 0.03*4*(T-3*Td/4)/Td+0.0607;
% xdy4 = 0.06001*4*(T-3*Td/4)/Td-0.06;
% xdz4 = -0.01*4*(T-3*Td/4)/Td+0.3959;
% rdx = [xdx1, xdx2, xdx3, xdx4];
% rdy = [xdy1, xdy2, xdy3, xdy4];
% rdz = [xdz1, xdz2, xdz3, xdz4];

%ʵ�ʹ켣
figure;
for i = 1:Td/step
    if (rem(i, inteval)==0)
        q = U(i,1:6)';
        index = index + 1;
        [px, py, pz] = position(q);
        %ĩ��
        pos(index, 1:3) = [px, py, pz];
        drawManipulator(q);
    end
end
h1 = plot3(rdx*1000, rdy*1000, rdz*1000,'r'); grid on;
hold on;
h2 = plot3(pos(1:number,1)'*1000, pos(1:number,2)'*1000, pos(1:number,3)'*1000,'-.o','color',[0.50, 0.54, 0.53],'MarkerFaceColor',[0.50, 0.54, 0.53]);
legend([h1, h2],'Desired path','Actual trajactory','Location','best', 'FontName', 'times new Roman');
hold off;
view(3);
xlabel('X (mm)', 'FontName', 'times new Roman');
ylabel('Y (mm)', 'FontName', 'times new Roman');
zlabel('Z (mm)', 'FontName', 'times new Roman');
savefig('results\circleKalman.fig');


